﻿using UnityEngine;
using System.Collections;

public class SparrowScript : enemyScript {
	// Unused for now, but should be kept for inheritance purposes

}
