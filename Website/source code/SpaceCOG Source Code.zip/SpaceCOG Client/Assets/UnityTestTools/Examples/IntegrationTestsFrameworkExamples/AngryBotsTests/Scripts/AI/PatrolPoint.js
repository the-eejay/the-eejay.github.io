#pragma strict

var position : Vector3;

function Awake () {
	position = transform.position;
}