
SpaceD UI (v.1)
July 21 2013

Art: EvilSystem (evil.duloclan.com / evil-s.deviantart.com )
Code: Chompi (skype - chikina6335)
Contact: evilsystem@duloclan.com / contact.evil@duloclan.com 


The skin contains buttons, toggles, radios, sliders, scrollbars, textfields, textareas, texts in two variants, amazing labels and additionally loading animation (Tiled png). We've added a testing scene with a script to demonstrate how to use the skin with all it's effects.


The product features:

- GUI
- Textures in PNG format
- PSD File
- All fonts included
- Testing scene


Contact me if you need any assistance or have a question. 
Regards Evil!